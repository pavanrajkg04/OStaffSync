def main():
    print("Hello from ostaffsync!")


if __name__ == "__main__":
    main()
